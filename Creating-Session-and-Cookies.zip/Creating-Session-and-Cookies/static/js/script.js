// Example script
console.log("JavaScript is loaded.");
